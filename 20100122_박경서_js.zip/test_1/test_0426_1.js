/* jslint devel: true */
/* eslint-disable no-console */
/* eslint no-undef: "error" */
/* eslint-env node */

/* 변수 만들기 */

var age = 22;
var name = '박경서';
var university = '남서울대';
var major = '지능정보통신공학과';
var studentnauber = 20100122;
var whatstudent = 'web server and db';

console.log('이름 : %s', name);
console.log('나이 : %d', age);
console.log('학교 : %s', university);
console.log('학번 : %s', studentnauber);
console.log('학과 : %s', major);
console.log('과목 : %s', whatstudent);
