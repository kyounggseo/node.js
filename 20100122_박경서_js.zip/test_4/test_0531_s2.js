/*jslint devel: ture */
/* eslint-disable no-console */
/* eslint no-undef:"error" */
/* eslint-env node */

var calc1 = {};
calc1.sub = function(a,b) {
    return a - b;
}
module.exports = calc1;