/* jslint devel: ture */
/* eslint-disable no-console */
/* eslint no-undef:"error" */
/* eslint-env node */

exports.mul = function(a,b) { 
    return a * b;
}
